function TemplatePointers(){
    return(
        <>
         <h1 className="text-2xl mt-8 font-bold">Dak Ghar Niryat Admin Dashboard </h1>
          
          <p className="py-2  mb-4">✓ <span className="font-semibold">Now exports made easy</span> </p>
        </>
    )
}

export default TemplatePointers