import React, { useEffect, useState } from 'react';

function PlotImages() {
  const [productPlot, setProductPlot] = useState('');
  const [monthPlot, setMonthPlot] = useState('');

  useEffect(() => {
    const fetchPlots = async () => {
      try {
        const response = await fetch('http://localhost:5000/plots');
        const responseData = await response.json();
        setProductPlot(responseData.product_plot);
        setMonthPlot(responseData.month_plot);
      } catch (error) {
        console.log('Error fetching plots:', error);
      }
    };

    fetchPlots();
  }, []);

  return (
    <div>
      <h2>Product Plot</h2>
      <img src={`data:image/png;base64,${productPlot}`} alt="Product Plot" />

      <h2>Month Plot</h2>
      <img src={`data:image/png;base64,${monthPlot}`} alt="Month Plot" />
    </div>
  );
}

export default PlotImages;